const G=`/* Work Timer — Floating Mini Timer Widget Styles\r
 * Injected into a ShadowDOM; uses CSS custom properties for dark/light theming.\r
 */\r
\r
/* --- Dark mode (default) --- */\r
:host {\r
  display: block !important;\r
  box-sizing: border-box;\r
  font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', sans-serif;\r
  line-height: normal;\r
  -webkit-font-smoothing: antialiased;\r
\r
  --wt-bg:            #1e1b4b;\r
  --wt-border:        rgba(129, 140, 248, 0.3);\r
  --wt-shadow:        rgba(0, 0, 0, 0.4);\r
  --wt-text:          #e0e7ff;\r
  --wt-timer:         #ffffff;\r
  --wt-project:       rgba(165, 180, 252, 0.8);\r
  --wt-close:         rgba(224, 231, 255, 0.5);\r
  --wt-close-hbg:     rgba(248, 113, 113, 0.2);\r
  --wt-close-hfg:     #f87171;\r
  --wt-pulse-run:     #6ee7b7;\r
  --wt-pulse-pause:   #fbbf24;\r
  --wt-btn-pause-bg:  rgba(251, 191, 36, 0.2);\r
  --wt-btn-pause-fg:  #fbbf24;\r
  --wt-btn-resume-bg: rgba(110, 231, 183, 0.2);\r
  --wt-btn-resume-fg: #6ee7b7;\r
  --wt-btn-stop-bg:   rgba(248, 113, 113, 0.2);\r
  --wt-btn-stop-fg:   #f87171;\r
}\r
\r
/* --- Light mode override (when extension theme is a light-* variant) --- */\r
:host([data-scheme="light"]) {\r
  --wt-bg:            #ffffff;\r
  --wt-border:        rgba(99, 102, 241, 0.25);\r
  --wt-shadow:        rgba(99, 102, 241, 0.15);\r
  --wt-text:          #312e81;\r
  --wt-timer:         #1e1b4b;\r
  --wt-project:       #6366f1;\r
  --wt-close:         rgba(67, 56, 202, 0.45);\r
  --wt-close-hbg:     rgba(239, 68, 68, 0.12);\r
  --wt-close-hfg:     #dc2626;\r
  --wt-pulse-run:     #059669;\r
  --wt-pulse-pause:   #d97706;\r
  --wt-btn-pause-bg:  rgba(217, 119, 6, 0.12);\r
  --wt-btn-pause-fg:  #b45309;\r
  --wt-btn-resume-bg: rgba(5, 150, 105, 0.12);\r
  --wt-btn-resume-fg: #047857;\r
  --wt-btn-stop-bg:   rgba(239, 68, 68, 0.12);\r
  --wt-btn-stop-fg:   #dc2626;\r
}\r
\r
#widget {\r
  background: var(--wt-bg);\r
  border: 1px solid var(--wt-border);\r
  border-radius: 12px;\r
  box-shadow: 0 8px 24px var(--wt-shadow);\r
  color: var(--wt-text);\r
  cursor: default;\r
  user-select: none;\r
  overflow: hidden;\r
  transition: border-radius 0.15s ease;\r
}\r
\r
#drag-handle {\r
  display: flex;\r
  align-items: center;\r
  gap: 8px;\r
  padding: 10px 10px 4px;\r
  cursor: pointer;\r
}\r
\r
#drag-handle:active { cursor: grabbing; }\r
\r
#pulse {\r
  width: 7px;\r
  height: 7px;\r
  border-radius: 50%;\r
  flex-shrink: 0;\r
  animation: pulse 1.5s infinite;\r
}\r
\r
#pulse.running { background: var(--wt-pulse-run); }\r
#pulse.paused  { background: var(--wt-pulse-pause); animation: none; }\r
\r
@keyframes pulse {\r
  0%   { opacity: 1; }\r
  50%  { opacity: 0.35; }\r
  100% { opacity: 1; }\r
}\r
\r
#timer {\r
  font-size: 13px;\r
  font-weight: 700;\r
  letter-spacing: 0.04em;\r
  color: var(--wt-timer);\r
  flex: 1;\r
  font-variant-numeric: tabular-nums;\r
}\r
\r
#close-btn {\r
  width: 18px;\r
  height: 18px;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  border-radius: 50%;\r
  border: none;\r
  background: transparent;\r
  color: var(--wt-close);\r
  cursor: pointer;\r
  font-size: 11px;\r
  line-height: 1;\r
  padding: 0;\r
  flex-shrink: 0;\r
}\r
\r
#close-btn:hover { background: var(--wt-close-hbg); color: var(--wt-close-hfg); }\r
\r
#body {\r
  padding: 0 10px 8px;\r
}\r
\r
#project-name {\r
  font-size: 10px;\r
  color: var(--wt-project);\r
  white-space: nowrap;\r
  overflow: hidden;\r
  text-overflow: ellipsis;\r
  max-width: 100%;\r
  margin-bottom: 6px;\r
}\r
\r
#actions {\r
  display: flex;\r
  gap: 4px;\r
}\r
\r
.action-btn {\r
  flex: 1;\r
  border: none;\r
  border-radius: 6px;\r
  font-size: 10px;\r
  font-weight: 600;\r
  padding: 4px 0;\r
  cursor: pointer;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  gap: 3px;\r
  transition: opacity 0.1s;\r
}\r
\r
.action-btn:hover { opacity: 0.85; }\r
.action-btn:active { transform: scale(0.96); }\r
\r
.btn-pause  { background: var(--wt-btn-pause-bg);  color: var(--wt-btn-pause-fg); }\r
.btn-resume { background: var(--wt-btn-resume-bg); color: var(--wt-btn-resume-fg); }\r
.btn-stop   { background: var(--wt-btn-stop-bg);   color: var(--wt-btn-stop-fg); }\r
\r
/* Mini mode: compact pill — click anywhere on handle to expand */\r
#widget.mini {\r
  border-radius: 20px;\r
}\r
\r
.mini #drag-handle { padding: 10px 12px; }\r
.mini #body { display: none; }\r
.mini #timer { font-size: 12px; }\r
.mini #close-btn { display: none; }\r
`;function L(t){return t.status==="running"&&t.startTime?t.elapsed+(Date.now()-t.startTime):t.elapsed}const M="floatingTimerPos",S="floatingTimerMin",k="floatingTimerHidden",_=96,R=200,N=40,W=100;let r=null,i=null,g=null,m=null,o=null,b=[],d=!1,f=!1,v=!0,A=!0,h=-1,w=-1;function P(t){const n=Math.floor(t/1e3),e=Math.floor(n/3600),s=Math.floor(n%3600/60),l=n%60,u=String(s).padStart(2,"0"),c=String(l).padStart(2,"0");return e>0?`${e}:${u}:${c}`:`${u}:${c}`}async function K(){const t=await chrome.storage.local.get([M,S,k,"settings"]),n=t[M];n&&(h=n.x,w=n.y),d=!!t[S],f=!!t[k];const e=t.settings;v=e?.floatingTimerAutoShow!==!1,A=!e?.theme?.startsWith("light")}function C(){if(!r)return;const{right:t,bottom:n}=j();chrome.storage.local.set({[M]:{x:t,y:n},[S]:d}).catch(()=>{})}function O(t){f=t,chrome.storage.local.set({[k]:t}).catch(()=>{})}function T(t,n){const e=d?_:R;return["position:fixed",`right:${t}px`,`bottom:${n}px`,"z-index:2147483647","display:block",`width:${e}px`].join(";")}function j(){const t=r?.getAttribute("style")||"";return{right:parseInt((t.match(/right:(\d+)px/)??["","20"])[1],10),bottom:parseInt((t.match(/bottom:(\d+)px/)??["","20"])[1],10)}}function F(){if(!r)return;const{right:t,bottom:n}=j(),e=d?_:R,s=Math.max(0,Math.min(window.innerWidth-e,t)),l=d?N:W,u=Math.max(0,Math.min(window.innerHeight-l,n));r.setAttribute("style",T(s,u))}function x(){r=document.createElement("work-timer-widget"),r.setAttribute("data-scheme",A?"dark":"light");const t=h>=0?h:20,n=w>=0?w:20;r.setAttribute("style",T(t,n)),i=r.attachShadow({mode:"open"});const e=document.createElement("style");e.textContent=G;const s=document.createElement("div");s.id="widget",s.className=d?"mini":"full",s.innerHTML=`
    <div id="drag-handle">
      <span id="pulse" class="paused"></span>
      <span id="timer">00:00</span>
      <button id="close-btn" title="Close widget">✕</button>
    </div>
    <div id="body">
      <div id="project-name">No project</div>
      <div id="actions">
        <button class="action-btn btn-pause" id="btn-pause" title="Pause">⏸ Pause</button>
        <button class="action-btn btn-stop" id="btn-stop" title="Stop">⏹ Stop</button>
      </div>
    </div>
  `,i.appendChild(e),i.appendChild(s),(document.body||document.documentElement).appendChild(r),i.getElementById("close-btn").addEventListener("click",l=>{l.stopPropagation(),O(!0),H()}),i.getElementById("drag-handle").addEventListener("click",l=>{l.target.closest("button")||(d=!d,s.className=d?"mini":"full",F(),C())}),i.getElementById("btn-pause").addEventListener("click",async()=>{o?.status==="running"?await chrome.runtime.sendMessage({action:"PAUSE_TIMER"}):o?.status==="paused"&&await chrome.runtime.sendMessage({action:"RESUME_TIMER"})}),i.getElementById("btn-stop").addEventListener("click",async()=>{await chrome.runtime.sendMessage({action:"STOP_TIMER"})}),X()}function X(){if(!i||!r)return;m?.abort(),m=new AbortController;const{signal:t}=m,n=i.getElementById("drag-handle");if(!n)return;let e=!1,s=0,l=0,u=0,c=0;n.addEventListener("mousedown",a=>{if(a.target.closest("button"))return;e=!0,s=a.clientX,l=a.clientY;const p=j();u=p.right,c=p.bottom,a.preventDefault()},{signal:t}),document.addEventListener("mousemove",a=>{if(!e||!r)return;const p=s-a.clientX,I=l-a.clientY,Y=d?_:R,$=Math.max(0,Math.min(window.innerWidth-Y,u+p)),U=d?N:W,z=Math.max(0,Math.min(window.innerHeight-U,c+I));r.setAttribute("style",T($,z))},{signal:t}),document.addEventListener("mouseup",()=>{e&&(e=!1,C())},{signal:t})}function y(t,n){if(!i)return;o=t;const e=i.getElementById("widget"),s=i.getElementById("pulse"),l=i.getElementById("timer"),u=i.getElementById("project-name"),c=i.getElementById("btn-pause");if(!e||!s||!l||!u||!c)return;if(t.status==="idle"){B();return}s.className=t.status==="running"?"running":"paused",l.textContent=P(L(t));const a=n.find(I=>I.id===t.projectId);let p="";a&&t.description?p=`${a.name} • ${t.description}`:t.description?p=t.description:a?p=a.name:p="No project",u.textContent=p,u.style.color=a?a.color:"rgba(165, 180, 252, 0.8)",t.status==="running"?(c.className="action-btn btn-pause",c.textContent="⏸ Pause",c.title="Pause"):(c.className="action-btn btn-resume",c.textContent="▶ Resume",c.title="Resume"),e.className=d?"mini":"full"}function H(){g&&(clearInterval(g),g=null),m&&(m.abort(),m=null),r&&(r.remove(),r=null,i=null)}function B(){H(),o=null,b=[]}function V(){g&&(clearInterval(g),g=null)}function E(){g||!o||o.status!=="running"||(g=setInterval(()=>{if(!i||!o||o.status!=="running"){V();return}const t=i.getElementById("timer");t&&(t.textContent=P(L(o)))},1e3))}function q(){!o||o.status==="idle"||f||!v||(r||x(),y(o,b),E())}function J(){H()}document.addEventListener("visibilitychange",()=>{document.visibilityState==="visible"?q():J()});chrome.runtime.onMessage.addListener(t=>{if(t.action==="RESTORE_TITLE"){document.title=t.originalTitle;return}if(t.action==="SHOW_FLOATING_TIMER"){const{state:n,projects:e}=t;O(!1),h=20,w=20,o=n,b=e,n.status!=="idle"&&document.visibilityState==="visible"&&(r?r.setAttribute("style",T(20,20)):x(),y(n,e),E());return}if(t.action==="TIMER_SYNC"){const{state:n,projects:e}=t;if(b=e,n.status==="idle"){B();return}if(o=n,document.visibilityState!=="visible")return;!r&&!f&&v&&x(),r&&(y(n,e),E())}});const D=["https://w-timer.com","https://www.w-timer.com"];(location.hostname==="localhost"||location.hostname==="127.0.0.1")&&D.push(location.origin);window.addEventListener("message",t=>{if(t.source===window){if(t.data?.type==="WORK_TIMER_PING"){window.postMessage({type:"WORK_TIMER_PONG"},location.origin);return}if(t.data?.type==="WORK_TIMER_AUTH"){if(!D.includes(location.origin))return;chrome.runtime.sendMessage({action:"AUTH_LOGIN",accessToken:t.data.accessToken,refreshToken:t.data.refreshToken},n=>{window.postMessage({type:"WORK_TIMER_AUTH_RESPONSE",success:n?.success??!1,error:chrome.runtime.lastError?.message||n?.error},location.origin)})}}});async function Q(){await K();try{chrome.runtime.sendMessage({action:"CONTENT_SCRIPT_READY"}).catch(()=>{});const t=await chrome.runtime.sendMessage({action:"GET_TIMER_STATE"});if(t?.success&&t.state&&t.state.status!=="idle"){const e=(await chrome.storage.local.get("projects")).projects??[];o=t.state,b=e,!f&&v&&document.visibilityState==="visible"&&(x(),y(o,e),E())}}catch{}}document.documentElement.tagName==="HTML"&&Q();
